import tkinter
from tkinter.constants import LEFT
import tkinter.ttk

def show(event=None):
    print("clicked")
    
    root.destroy()


root = tkinter.Tk()
root.geometry('400x300')
my_text = tkinter.Text(root)
my_text.config(wrap='word',relief=tkinter.FLAT)   #wrap first line me next word 

my_scroll_bar = tkinter.ttk.Scrollbar(root)
my_scroll_bar.pack(side=tkinter.RIGHT,fill=tkinter.Y)
my_text.pack(fill=tkinter.BOTH,expand=True)
my_scroll_bar.config(command=my_text.yview)  #connect scroll bar to text
my_text.config(yscrollcommand=my_scroll_bar.set)  # connect text to scroll bar

b1 = tkinter.Button(root)
#b2 = tkinter.Button(root)
b1.pack()

b1.config(text= "show")
b1.config(text="dis")
#root ke cross event ko dissable krna hai 
root.protocol("WM_DELETe_WINDOW",show)  #wm: windows manager

root.mainloop()


