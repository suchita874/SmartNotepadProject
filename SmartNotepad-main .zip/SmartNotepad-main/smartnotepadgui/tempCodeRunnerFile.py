
    def exit_func(self, event=None):
        try:
            if self.text_changed:
                mbox = messagebox.askyesno("File not saved","Do you want to save the file")
                if mbox is True:
                    content  = self.text_editor.get(1.0,tk.END)
                    self.file_controller.save_file(content)
        except:
            messagebox.showerror("AppError","Error in closing")
            print(traceback.format_exc())
        finally:
            messagebox.showinfo("Thank you","Have a nice day")
            self.db_controller.close_notepad()
            self.root.destroy()

    def save_file(self, event=None):
        try:
            content=self.text_editor.get(1.0,tk.END)  # fetch data from text
            self.file_controller.save_file(content)
        except:
            messagebox.showerror("Error","Cannot save the file")
            print(traceback.format_exc())


    def save_as(self, event=None):
        try:
            content = self.text_editor.get(1.0,tk.END)
            self.file_controller.save_as(content)
        except:
            messagebox.showerror("Error","Cannot save the file")
            print(traceback.format_exc())



    def open_file(self, event=None):
        try:
            self.msg,self.base= self.file_controller.read_file("")
            if self.db_controller.is_secure_file(self.base):
                pwd = self.get_file_pwd()
                if pwd == self.db_controller.get_file_pwd(self.base):
                    self.text_editor.delete(1.0,tk.END)
                    self.text_editor.insert(1.0,self.msg)
                    self.root.title(self.base)
                else:
                    messagebox.showerror("Wrong Password","Wrong Password! Please Try Again!!")
            else:
                self.text_editor.delete(1.0,tk.END)
                self.text_editor.insert(1.0,self.msg)
                self.root.title(self.base)
        except FileNotFoundError:
            print(traceback.format_exc())
        except:
            print(traceback.format_exc())

    def new_file(self, event=None):
        self.file_controller.new_file()
        self.root.title("MyNotePad")
        self.text_editor.delete(1.0,tk.END)


    def changed(self, event=None):
        if self.text_editor.edit_modified():
            self.text_changed = True
            words = len(self.text_editor.get(1.0,'end-1c').split())
            characters = len(self.text_editor.get(1.0,'end-1c'))
            self.status_bar.config(text=f'Characters : {characters} Words : {words}')
            self.text_editor.edit_modified(False)

    def find(self):
        word = self.find_input.get()
        self.text_editor.tag_remove("match",'1.0',tk.END)
        matches = 0
        if word:
            start_pos = '1.0'
            while True:
                start_pos = self.text_editor.search(word,start_pos,topindex=tk.END)
                if not start_pos:
                    break
                end_pos = f'{start_pos}+{len(word)}c'
                print("st:",start_pos,"end :",end_pos)
                self.text_editor.tag_add("match",start_pos,end_pos)
                matches += 1
                start_pos = end_pos
                self.text_editor.tag_config("match",foreground='red',background='yellow')

    def replace(self):
        word = self.find_input.get()
        replace_text = self.replace_input.get()
        if len(word.trim()==0) or (len(replace_text.trim()==0)):
            return
        content = self.text_editor.get(1.0,tk.END)
        new_content = content.replace(word,replace_text)
        self.text_editor.delete(1.0,tk.END)
        self.text_editor.insert(1.0,new_content)



    def find_func(self, event=None):
        self.find_dialogue = tk.Toplevel()
        self.find_dialogue.geometry('450x250+500+200')
        self.find_dialogue.resizable(0,0)
        ##frame
        self.find_frame = ttk.LabelFrame(self.find_dialogue,text = "Find/Replace")
        self.find_frame.pack(pady = 20)
        ##labels
        self.text_find_label = ttk.Label(self.find_frame,text="Find :")
        self.text_replace_label = ttk.Label(self.find_frame,text = "Replace")
        ##entry
        self.find_input = ttk.Entry(self.find_frame,width=30)
        self.replace_input = ttk.Entry(self.find_frame,width=30)

        ##button
        self.find_button = ttk.Button(self.find_frame,text="Find",command=self.find)
        self.replace_button = ttk.Button(self.find_frame,text="Replace",command=self.replace)
        ##label grid
        self.text_find_label.grid(row=0,column=0,padx=4,pady=4)
        self.text_replace_label.grid(row=1,column=0,padx=4,pady=4)
        ##entry grid
        self.find_input.grid(row=0,column=1,padx=4,pady=4)
        self.replace_input.grid(row=1,column=1,padx=4,pady=4)
        ##button grid
        self.find_button.grid(row=2,column=0,padx=8,pady=4)
        self.replace_button.grid(row=2,column=1,padx=8,pady=4)

        self.find_dialogue.mainloop()

    def say_something(self):
        try:
            self.takeAudio = self.file_controller.take_query()
            if self.takeAudio == "":
                messagebox.showinfo("say again","speech not recognized!!")
            elif self.takeAudio.lower() == "hey mojo open file":
                self.save_file()
            elif self.takeAudio.lower() == "hey mojo save file":
                self.save_file()
            elif  self.takeAudio.lower() == "hey mojo new file":
                self.new_file
            elif self.takeAudio.lower() == "hey mojo file save":
                self.save_as()
            elif self.takeAudio.lower() == "hey mojo close app":
                self.exit_func()
            elif self.takeAudio.lower() == "hey mojo text bold":
                self.change_bold()
            elif self.takeAudio.lower() == "hey mojo text italic":
                self.change_italic()
            elif self.takeAudio.lower() == "hey mojo search":
                self.find_func()
            elif self.takeAudio.lower() == "hey mojo hide statusbar":
                self.hide_statusbar()
            elif self.takeAudio.lower() == "hey mojo hide toolbar":
                self.hide_toolbar()
            else:
                messagebox.showerror("Error","sorry ! Your audio did not match")

        except RequestError as requeue:
            messagebox.showerror("no internet","Please check your internet connection")
        except WaitTimeoutError as waiter:
            messagebox.showerror("Time over","Time limit exceed")
        except UnknownValueError as unknew:
            messagebox.showerror("Non Translatable text","speech unrecognizable")

    def align_left(self):
        text_content = self.text_editor.get(1.0,'end')
        self.text_editor.tag_config('left',justify=tk.LEFT)
        self.text_editor.delete(1.0,tk.END)
        self.text_editor.insert(tk.INSERT,text_content,'left')

    def align_center(self):
        
        text_content = self.text_editor.get(1.0,'end')
        self.text_editor.tag_config('center',justify=tk.CENTER)
        self.text_editor.delete(1.0,tk.END)
        self.text_editor.insert(tk.INSERT,text_content,'center')

    def align_right(self):
       
        text_content = self.text_editor.get(1.0,'end')
        self.text_editor.tag_config('right',justify=tk.RIGHT)
        self.text_editor.delete(1.0,tk.END)
        self.text_editor.insert(tk.INSERT,text_content,'right')

    def change_font_color(self):
        color_var = tk.colorchooser.askcolor()
        self.text_editor.config(fg=color_var[1])
    


    def hide_toolbar(self):  #how to delete anything from window root in tkinter
        if self.show_toolbar:
            self.tool_bar.pack_forget()
            self.show_toolbar=False
        else:    #phle baaki sab htenge qki without that toolbar neeche shift ho jaega wki text widget oopar chala jaega jab toolbar hatega
            self.text_editor.pack_forget()
            self.status_bar.pack_forget()
            self.tool_bar.pack(side=tk.TOP,fill=tk.X)
            self.text_editor.pack(fill=tk.BOTH,expand=True)
            self.status_bar.pack(side=tk.BOTTOM)
            self.show_toolbar=True


    def hide_statusbar(self):
        if self.status_bar:
            self.status_bar.pack_forget()
            self.status_bar=False
        else:
            self.status_bar.pack(side=tk.BOTTOM)
            self.status_bar = True


    def change_theme(self):
        self.choosen_theme = self.theme_choice.get()
        self.color_tuple = self.color_dict.get(self.choosen_theme)
        fg_color,bg_color = self.color_tuple
        self.text_editor.config(background=bg_color,foreground=fg_color)


    def change_font(self, event=None):
        self.current_font_family = self.font_family.get()
        self.text_editor.configure(font=(self.current_font_family,self.current_font_size))

    def change_fontsize(self, event=None):
        self.current_font_size = self.size_var.get()
        self.text_editor.configure(font=(self.current_font_family,self.current_font_size))

    def change_bold(self):
        self.text_property = tk.font.Font(font=self.text_editor['font'])
        if self.text_property.actual()['weight'] == 'normal':
            self.text_editor.config(font=(self.current_font_family,self.current_font_size,'bold'))
        if self.text_property.actual()['weight'] == 'bold':
            self.text_editor.config(font=(self.current_font_family,self.current_font_size,'normal'))

    def change_italic(self):
        self.text_property = tk.font.Font(font=self.text_editor['font'])
        if self.text_property.actual()['slant'] == 'normal':
            self.text_editor.config(font=(self.current_font_family,self.current_font_size,'italic'))
        if self.text_property.actual()['slant'] == 'italic':
            self.text_editor.config(font=(self.current_font_family,self.current_font_size,'normal'))

    def change_underline(self):
        self.text_property = tk.font.Font(font=self.text_editor['font'])
        if self.text_property.actual()['weight'] == '0':
            self.text_editor.config(font=(self.current_font_family,self.current_font_size,'roman'))
        if self.text_property.actual()['weight'] == '1':
            self.text_editor.config(font=(self.current_font_family,self.current_font_size,'normal'))

    def secure_file(self, event=None):
        if self.db_status:
            self.file_dialogue = tk.Toplevel()
            self.file_dialogue.geometry('450x400+500+200')
            self.file_dialogue.title("Secure Files")
            self.file_dialogue.resizable(0,0)
            ##frame
            self.file_frame = ttk.LabelFrame(self.file_dialogue,text = "Add Secure File")
            self.file_frame.pack(pady = 20)
            ##labels
            self.text_file_owner_label = ttk.Label(self.file_frame,text="File Owner :")
            self.text_file_pwd_label = ttk.Label(self.file_frame,text = "File Password :")
            self.total_file = self.db_controller.get_file_count()
            self.total_file_label = ttk.Label(self.file_frame,text = f"Total Files: {self.total_file}")
            ##entry
            self.file_owner_input = ttk.Entry(self.file_frame,width=30)
            self.file_pwd_input = ttk.Entry(self.file_frame,width=30)

            ##button
            self.file_add_button = ttk.Button(self.file_frame,text="Add File",command=self.add_file)
            self.file_open_button = ttk.Button(self.file_frame,text="Open File",command=self.open_secure_file)
            self.file_remove_button = ttk.Button(self.file_frame,text="Remove File",command=self.remove_secure_file)

            ##label grid
            self.text_file_owner_label.grid(row=0,column=0,padx=4,pady=4)
            self.text_file_pwd_label.grid(row=1,column=0,padx=4,pady=4)
            self.total_file_label.grid(row=3,column=0,padx=4,pady=4)
            ##entry grid
            self.file_owner_input.grid(row=0,column=1,padx=4,pady=4)
            self.file_pwd_input.grid(row=1,column=1,padx=4,pady=4)

            ##button grid
            self.file_add_button.grid(row=2,column=0,padx=8,pady=4)
            self.file_open_button.grid(row=2,column=1,padx=8,pady=4)
            self.file_remove_button.grid(row=2,column=2,padx=8,pady=4)

            ## scrollabel list
            scrollbar = ttk.Scrollbar(self.file_dialogue,orient="vertical")
            scrollbar.pack(side='right',fill="both")
            self.fileList = tk.Listbox(self.file_dialogue)
            self.fileList.pack(fill='both',expand=True)
            self.fileList.configure(background="white")
            self.fileList.configure(disabledforeground="#a3a3a3")
            self.fileList.configure(font="Lato")
            self.fileList.configure(foreground="black")
            self.fileList.configure(highlightbackground="#d9d9d9")
            self.fileList.configure(highlightcolor="#d9d9d9")
            self.fileList.configure(selectbackground="#c4c4c4")
            self.fileList.configure(selectforeground="black")
            self.fileList.configure(width=10)
            self.fileList.configure(yscrollcommand=scrollbar.set)
            scrollbar.configure(command=self.fileList.yview)
            self.fileList.bind("<Double-1>",self.list_double_click)

            ##load file from Db
            for values in self.files.keys():
                self.f_name = values
                file_owner = self.files.get(self.f_name)[1]
                full_file = self.f_name+"  "+"[ Owner:"+file_owner+"]"
                self.fileList.insert("end",full_file)
                self.file_dialogue.mainloop()
        else:
            messagebox.showerror("Database Error","Please Connect with the database")

        
