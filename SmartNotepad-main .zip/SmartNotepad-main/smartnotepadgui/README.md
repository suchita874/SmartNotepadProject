# SmartNotepadProject
It is a smart notepad developed by using Tkinter module of python it has speech recognition feature and also secure files option to encrypt your file.
