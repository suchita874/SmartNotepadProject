'''import string

result = ""
a = "Bhopal indore"
offset = 5
string = string.ascii_letters+"0123456789" #ab b ka index apni string me dekhenge or +5 kr denge fir jo index aaya uska index humari string me jo character hai wo save hoga uss index me
# for space it simply concatenate the character mod with len of string 9 ka index 66 % 62 4 then out of range nhi jaega
for i in a:
    try:
        ind =string.index(i)
        ind = (ind+offset)%62
        result += string[ind]

    except ValueError:
        result += '@'

print(result)'''
#print(7%4) # maths general nhi lagati oython in this statement'''open distribution principle a_b*math.floor(a/b) mod sign is always denomentor this is opposite of c,c++,java (numerator)
# -7%4 = 1 (-7-4*math.floor(-7/4))  -1%62 = 61


    

