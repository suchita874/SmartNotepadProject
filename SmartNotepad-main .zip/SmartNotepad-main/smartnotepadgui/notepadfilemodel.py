#from cx_Oracle import*
#from traceback import*
from tkinter import filedialog
import os

import string

class file_model:
    def __init__(self):
        self.url = ""
        #self.key = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" or string module mepython ke andar ek variable hai ascii_lowercase/ascii_uppercase wich give abcd...ABC... and ascii_letters give all alphabateof lower and uppercase
        #self.key = string.ascii_letters+"0123456789"
        self.key = string.ascii_letters+''.join([str(x) for x in range(0,10)])
        self.offset = 5

    def encrypt(self,plaintext):
        result = ""
        for ch in plaintext:
            try:
                ind = self.key.index(ch) # index fuction give error when index not found isliye try except lgana padega
                ind = (ind+self.offset)%62
                result+=self.key[ind]
            except ValueError:
                result += ch
        return result


    def decrypt(self,ciphertext):
        result = ""
        for ch in ciphertext:
            try:
                ind = self.key.index(ch) # index fuction give error when index not found isliye try except lgana padega
                ind = (ind-self.offset)%62
                result+=self.key[ind]
            except ValueError:
                result += ch
        return result


    def open_file(self):
        self.url = filedialog.askopenfilename(title="select file",filetypes=[("text document","*.*")]) # *.* choose all type of file but for mp3 mp humara project kaaam nhi krega we can check it by self
    def new_file(self):
        self.url = ""  # empty file open

    def save_As(self,msg):
        encrypted_text = self.encrypt(msg)
        self.url = filedialog.asksaveasfile(mode="w",defaultextension='.ntxt',filetypes=[("All Files","*.*"),("Text Document")])
        #self.url is TextIoWrapper object it have write method
        self.url.write(encrypted_text)  #program band hoga to file ka name miss ho jaega like when save_as then click on save_as it save without asking name of file
        filepath = self.url.name
        self.url.close()
        self.url=filepath

    def save_File(self,msg):
        if self.url == "":
            self.url = filedialog.asksaveasfilename(title="Select file name",defaultextension='.ntxt',filetypes=[("All Files","*.*"),("Text Document")])
        file_name,file_extension = os.path.splitext(self.url)
        if file_extension == '.ntxt':
            msg = self.encrypt(msg)
        with open(self.url,"w",encoding="utf-8") as fw:   
            fw.write(msg)



    #secured files which are stored in database

    def read_file(self,url=""):
        if url!='':
            self.url = url
        else:
            self.open_file()
        base = os.path.basename(self.url)
        file_name,file_extension = os.path.splitext(self.url)
        fr = open(self.url,"r")
        contents = fr.read()
        if file_extension == '.ntxt':
            contents = self.decrypt(contents)
        fr.close()
        return contents,base



obj=file_model()
#print(obj.read_file(''))
#print(obj.encrypt("bhopal"))
'''plaintext = "Bhopal"
cipher = obj.encrypt(plaintext)
print(cipher)
print(obj.decrypt(cipher))'''





