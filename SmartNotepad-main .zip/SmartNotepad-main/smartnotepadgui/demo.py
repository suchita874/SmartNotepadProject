import speech_recognition as s  # pyaudio ko internally usse by speech recognition

#recognizer class  microphone se audio record karaegi or text me convert karegi  iske pas ye kaam krne ke method hain

def take_query():
    sr = s.Recognizer()
    print("say something")
    #m = s.Microphone()   #microphone class ka object jab crete hog tb "dunde renter" and "dunder exit" when recording finish
    #with block ka benifit se do method call nhi karna paega hume
    with s.Microphone() as m:
        try:
            audio = sr.listen(m)
            text = sr.recognize_google(audio,language="en-IN")  # in hindi 'hi-IN' 
            return text
        except:
            print("Exception occurred")




print("you said ",take_query())

